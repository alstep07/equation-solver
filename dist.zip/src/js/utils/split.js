export default (string) => {
  const arr = [];
  for (const char of string) arr.push(char);

  return arr;
};
